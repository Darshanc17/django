from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('calculator/', views.sip_calculator, name='sip_calculator'),
    path('cagr/', views.cagr_calculator, name='cagr_calculator'),
    path('cagr', views.cagr_calculator, name='cagr_calculator_no_slash'),
]
