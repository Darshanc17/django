from django.shortcuts import render

def home(request):
    return render(request, "sip/home.html")


def sip_calculator(request):
    result = None
    chart_data = []
    sudden_rise_index = None

    if request.method == "POST":
        monthly_investment = float(request.POST.get("monthly_investment", 0))
        expected_rate = float(request.POST.get("expected_rate", 0)) / 100
        years = int(request.POST.get("years", 0))
        inflation_rate = float(request.POST.get("inflation_rate", 0) or 0) / 100

        months = years * 12
        monthly_rate = expected_rate / 12

        # Track year-end values
        future_value = 0
        for month in range(1, months + 1):
            future_value = future_value * (1 + monthly_rate) + monthly_investment
            if month % 12 == 0:
                chart_data.append(round(future_value, 2))

        # Detect sudden rise (based on delta growth)
        for i in range(2, len(chart_data)):
            prev_growth = chart_data[i-1] - chart_data[i-2]
            current_growth = chart_data[i] - chart_data[i-1]
            if prev_growth > 0 and current_growth / prev_growth > 1.5:
                sudden_rise_index = i  # 0-based index
                break

        # Inflation-adjusted value
        if inflation_rate:
            real_rate = ((1 + expected_rate) / (1 + inflation_rate)) - 1
            real_monthly_rate = real_rate / 12
            real_future_value = 0
            for month in range(1, months + 1):
                real_future_value = real_future_value * (1 + real_monthly_rate) + monthly_investment
            result = round(real_future_value, 2)
        else:
            result = round(future_value, 2)

    return render(request, "sip/sip.html", {
        "result": result,
        "chart_data": chart_data,
        "sudden_rise_index": sudden_rise_index,
    })

def cagr_calculator(request):
    result = None

    if request.method == 'POST':
        try:
            initial_value = float(request.POST.get('initial_value', 0))
            final_value = float(request.POST.get('final_value', 0))
            years = float(request.POST.get('years', 0))

            if initial_value > 0 and final_value > 0 and years > 0:
                # CAGR formula: ((FV / IV)^(1/years)) - 1
                cagr = (final_value / initial_value) ** (1 / years) - 1
                result = round(cagr * 100, 2)  # convert to percentage with 2 decimals
            else:
                result = "Please enter positive values for all fields."
        except (ValueError, ZeroDivisionError):
            result = "Invalid input. Please enter numeric values greater than zero."

    return render(request, 'sip/cagr_calculator.html', {'result': result})
